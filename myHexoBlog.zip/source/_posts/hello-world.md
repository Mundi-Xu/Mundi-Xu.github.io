---
title: Hello World
date: 2018-10-25 17:21
live2d: true
---
## Welcome to My Blog ! This is my first post ##

## My Instagram: mundi.xu##

## Thank You for Liking Me ###

<!-- more-->

![hello-world](https://raw.githubusercontent.com/Mundi-Xu/picture_resource/master/picture/Hello%20World/hello_world.png)
